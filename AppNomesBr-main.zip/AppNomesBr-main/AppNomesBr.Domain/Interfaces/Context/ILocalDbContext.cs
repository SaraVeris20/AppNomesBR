﻿namespace AppNomesBr.Domain.Interfaces.Context
{
    public interface ILocalDbContext
    {
    }
}
